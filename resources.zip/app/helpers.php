<?php

function paginationHeaderInfo($data)
{
    $optiontext = '';
}
